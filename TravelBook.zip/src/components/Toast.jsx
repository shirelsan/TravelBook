import { useState, useCallback, createContext, useContext } from 'react';
import '../styles/Toast.css';
 
const ToastContext = createContext(null);
 
export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
 
  const addToast = useCallback((message, type = 'success') => {
    const id = Date.now();
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), 3000);
  }, []);
 
  return (
    <ToastContext.Provider value={addToast}>
      {children}
      <div className="toast-container">
        {toasts.map((t) => (
          <div key={t.id} className={`toast toast-${t.type}`}>
            <span>{t.type === 'success' ? '✓' : t.type === 'error' ? '✕' : 'ℹ'}</span>
            {t.message}
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}
 
export function useToast() {
  return useContext(ToastContext);
}
 